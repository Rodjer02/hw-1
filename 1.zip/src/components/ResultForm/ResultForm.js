import { Link } from "@chakra-ui/react";
import Button from "../Button/Button";
import { GrAction } from "react-icons/gr";
export default function ResultForm() {
  return (
    <div
      className="resultForm"
      style={{ display: "flex", flexDirection: "column", gap: "10px" }}
    >
      <Link href="https://chakra-ui.com" isExternal>
        Chakra Design system <GrAction mx="2px" />
      </Link>
      <Button />
    </div>
  );
}
