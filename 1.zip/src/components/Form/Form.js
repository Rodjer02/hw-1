import Button from "../Button/Button";
import Input from "../Input/Input";

export default function () {
  return (
    <div className="form">
      <Input />
      <Button />
    </div>
  );
}
