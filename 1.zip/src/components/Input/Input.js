import { Input } from "@chakra-ui/react";

export default function defaultInput() {
  return <Input variant="outline" placeholder="Outline" onChange="" />;
}
