import { Button } from "@chakra-ui/react";

export default function defaultButton() {
  return (
    <Button
      colorScheme="blue"
      variant="outline"
      onClick=""
      style={{ width: "max-content" }}
    >
      Button
    </Button>
  );
}
