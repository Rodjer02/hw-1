import Form from "./components/Form/Form";
import ResultForm from "./components/ResultForm/ResultForm";

function App() {
  return (
    <div className="App">
      <Form />
      <ResultForm />
    </div>
  );
}

export default App;
